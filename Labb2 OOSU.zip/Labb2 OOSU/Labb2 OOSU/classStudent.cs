﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{
    public class classStudent : classPerson
    {
       

        //Klasses egna
        private string _studentID;
        private string _antagningsDatum;
        private string _kursIDs;
       
        public string StudentID
        {
            get { return _studentID; }
            set { _studentID = value; }
        }

        public string AntagningsDatum
        {
            get { return _antagningsDatum; }
            set { _antagningsDatum = value; }
        }

        public string KursID
        {
            get { return _kursIDs; }
            set { _kursIDs = value; }

        }

        

     
        // Construktor
        public classStudent(string namn, string personNr, string studentId, string antagningsDatum, string kursid) : base(namn, personNr)
        {
            Namn = namn;
            PersonNR = personNr;
            StudentID = studentId;
            AntagningsDatum = antagningsDatum;
            KursID = kursid;
            

        }

        

    }
   
    

    

}
