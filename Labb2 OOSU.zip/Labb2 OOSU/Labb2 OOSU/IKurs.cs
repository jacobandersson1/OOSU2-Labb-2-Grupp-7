﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{
  public  interface IKurs
  {
        string KursNamn { get; set; }
        string StartDatum { get; set; }
        string SlutDatum { get; set; }
       
        /*  public void ListaKurser();
            public void SkapaKurs();
            public void ListaStudenter();
          */
    }
}
