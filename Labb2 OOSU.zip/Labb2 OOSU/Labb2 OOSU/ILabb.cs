﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{
   public interface ILabb
    {
        string Namn { get; set; }
        string LabbId { get; set; }
        string StartDatum { get; set; }
        string SlutDatum { get; set; }
    }
}
