﻿namespace Labb2_OOSU
{
    partial class RegKurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxKursNamn = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxKursID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxSlutDatum = new System.Windows.Forms.TextBox();
            this.listaKurser = new System.Windows.Forms.ListBox();
            this.buttonRegistrera = new System.Windows.Forms.Button();
            this.buttonLista = new System.Windows.Forms.Button();
            this.buttonTillbaka = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxStartDatum = new System.Windows.Forms.TextBox();
            this.buttonRegLab = new System.Windows.Forms.Button();
            this.dataGridViewKurs = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKurs)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxKursNamn
            // 
            this.textBoxKursNamn.Location = new System.Drawing.Point(68, 91);
            this.textBoxKursNamn.Multiline = true;
            this.textBoxKursNamn.Name = "textBoxKursNamn";
            this.textBoxKursNamn.Size = new System.Drawing.Size(146, 41);
            this.textBoxKursNamn.TabIndex = 0;
            this.textBoxKursNamn.TextChanged += new System.EventHandler(this.textBoxKursNamn_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "KursNamn";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "KursID";
            // 
            // textBoxKursID
            // 
            this.textBoxKursID.Location = new System.Drawing.Point(68, 186);
            this.textBoxKursID.Multiline = true;
            this.textBoxKursID.Name = "textBoxKursID";
            this.textBoxKursID.Size = new System.Drawing.Size(146, 41);
            this.textBoxKursID.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(84, 348);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label4.Size = new System.Drawing.Size(85, 20);
            this.label4.TabIndex = 8;
            this.label4.Text = "SlutDatum";
            // 
            // textBoxSlutDatum
            // 
            this.textBoxSlutDatum.Location = new System.Drawing.Point(68, 382);
            this.textBoxSlutDatum.Multiline = true;
            this.textBoxSlutDatum.Name = "textBoxSlutDatum";
            this.textBoxSlutDatum.Size = new System.Drawing.Size(146, 41);
            this.textBoxSlutDatum.TabIndex = 7;
            // 
            // listaKurser
            // 
            this.listaKurser.FormattingEnabled = true;
            this.listaKurser.ItemHeight = 20;
            this.listaKurser.Location = new System.Drawing.Point(334, 91);
            this.listaKurser.Name = "listaKurser";
            this.listaKurser.Size = new System.Drawing.Size(295, 184);
            this.listaKurser.TabIndex = 9;
            // 
            // buttonRegistrera
            // 
            this.buttonRegistrera.Location = new System.Drawing.Point(334, 348);
            this.buttonRegistrera.Name = "buttonRegistrera";
            this.buttonRegistrera.Size = new System.Drawing.Size(108, 35);
            this.buttonRegistrera.TabIndex = 10;
            this.buttonRegistrera.Text = "Registrera";
            this.buttonRegistrera.UseVisualStyleBackColor = true;
            this.buttonRegistrera.Click += new System.EventHandler(this.buttonRegistrera_Click);
            // 
            // buttonLista
            // 
            this.buttonLista.Location = new System.Drawing.Point(334, 294);
            this.buttonLista.Name = "buttonLista";
            this.buttonLista.Size = new System.Drawing.Size(108, 35);
            this.buttonLista.TabIndex = 11;
            this.buttonLista.Text = "Lista";
            this.buttonLista.UseVisualStyleBackColor = true;
            this.buttonLista.Click += new System.EventHandler(this.buttonLista_Click);
            // 
            // buttonTillbaka
            // 
            this.buttonTillbaka.Location = new System.Drawing.Point(660, 403);
            this.buttonTillbaka.Name = "buttonTillbaka";
            this.buttonTillbaka.Size = new System.Drawing.Size(108, 35);
            this.buttonTillbaka.TabIndex = 13;
            this.buttonTillbaka.Text = "Tillbaka";
            this.buttonTillbaka.UseVisualStyleBackColor = true;
            this.buttonTillbaka.Click += new System.EventHandler(this.buttonTillbaka_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 252);
            this.label3.Name = "label3";
            this.label3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label3.Size = new System.Drawing.Size(92, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "StartDatum";
            // 
            // textBoxStartDatum
            // 
            this.textBoxStartDatum.Location = new System.Drawing.Point(68, 288);
            this.textBoxStartDatum.Multiline = true;
            this.textBoxStartDatum.Name = "textBoxStartDatum";
            this.textBoxStartDatum.Size = new System.Drawing.Size(146, 41);
            this.textBoxStartDatum.TabIndex = 14;
            // 
            // buttonRegLab
            // 
            this.buttonRegLab.Location = new System.Drawing.Point(477, 294);
            this.buttonRegLab.Name = "buttonRegLab";
            this.buttonRegLab.Size = new System.Drawing.Size(108, 58);
            this.buttonRegLab.TabIndex = 16;
            this.buttonRegLab.Text = "Registrera Labb";
            this.buttonRegLab.UseVisualStyleBackColor = true;
            this.buttonRegLab.Click += new System.EventHandler(this.buttonRegLab_Click);
            // 
            // dataGridViewKurs
            // 
            this.dataGridViewKurs.AllowUserToAddRows = false;
            this.dataGridViewKurs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKurs.Location = new System.Drawing.Point(334, 46);
            this.dataGridViewKurs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewKurs.Name = "dataGridViewKurs";
            this.dataGridViewKurs.ReadOnly = true;
            this.dataGridViewKurs.Size = new System.Drawing.Size(360, 231);
            this.dataGridViewKurs.TabIndex = 17;
            // 
            // RegKurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 449);
            this.Controls.Add(this.dataGridViewKurs);
            this.Controls.Add(this.buttonRegLab);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxStartDatum);
            this.Controls.Add(this.buttonTillbaka);
            this.Controls.Add(this.buttonLista);
            this.Controls.Add(this.buttonRegistrera);
            this.Controls.Add(this.listaKurser);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxSlutDatum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxKursID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxKursNamn);
            this.Name = "RegKurs";
            this.Text = "RegistreraKurs";
            this.Load += new System.EventHandler(this.RegKurs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKurs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxKursNamn;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxKursID;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxSlutDatum;
        private System.Windows.Forms.ListBox listaKurser;
        private System.Windows.Forms.Button buttonRegistrera;
        private System.Windows.Forms.Button buttonLista;
        private System.Windows.Forms.Button buttonTillbaka;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxStartDatum;
        private System.Windows.Forms.Button buttonRegLab;
        private System.Windows.Forms.DataGridView dataGridViewKurs;
    }
}