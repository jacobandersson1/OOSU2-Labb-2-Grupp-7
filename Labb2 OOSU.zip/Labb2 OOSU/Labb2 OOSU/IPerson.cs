﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{

    public interface IPerson
    {
      string Namn { get; set; }
    }

    

}
