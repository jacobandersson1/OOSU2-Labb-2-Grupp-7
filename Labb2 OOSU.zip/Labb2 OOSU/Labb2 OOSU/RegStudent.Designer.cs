﻿namespace Labb2_OOSU
{
    partial class RegStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonTillbaka = new System.Windows.Forms.Button();
            this.buttonLista = new System.Windows.Forms.Button();
            this.buttonRegistrera = new System.Windows.Forms.Button();
            this.listaStudenter = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxAntagningsDatum = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxStudentD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxStudentNamn = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxPNR = new System.Windows.Forms.TextBox();
            this.textBoxKursIDS = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridViewStudent = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonTillbaka
            // 
            this.buttonTillbaka.Location = new System.Drawing.Point(985, 514);
            this.buttonTillbaka.Name = "buttonTillbaka";
            this.buttonTillbaka.Size = new System.Drawing.Size(108, 35);
            this.buttonTillbaka.TabIndex = 26;
            this.buttonTillbaka.Text = "Tillbaka";
            this.buttonTillbaka.UseVisualStyleBackColor = true;
            this.buttonTillbaka.Click += new System.EventHandler(this.buttonTillbaka_Click);
            // 
            // buttonLista
            // 
            this.buttonLista.Location = new System.Drawing.Point(985, 458);
            this.buttonLista.Name = "buttonLista";
            this.buttonLista.Size = new System.Drawing.Size(108, 35);
            this.buttonLista.TabIndex = 24;
            this.buttonLista.Text = "Lista Student";
            this.buttonLista.UseVisualStyleBackColor = true;
            this.buttonLista.Click += new System.EventHandler(this.buttonLista_Click);
            // 
            // buttonRegistrera
            // 
            this.buttonRegistrera.Location = new System.Drawing.Point(985, 397);
            this.buttonRegistrera.Name = "buttonRegistrera";
            this.buttonRegistrera.Size = new System.Drawing.Size(108, 35);
            this.buttonRegistrera.TabIndex = 23;
            this.buttonRegistrera.Text = "Registrera Student";
            this.buttonRegistrera.UseVisualStyleBackColor = true;
            this.buttonRegistrera.Click += new System.EventHandler(this.buttonRegistrera_Click);
            // 
            // listaStudenter
            // 
            this.listaStudenter.FormattingEnabled = true;
            this.listaStudenter.ItemHeight = 20;
            this.listaStudenter.Location = new System.Drawing.Point(404, 51);
            this.listaStudenter.Name = "listaStudenter";
            this.listaStudenter.Size = new System.Drawing.Size(295, 184);
            this.listaStudenter.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 529);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 20);
            this.label3.TabIndex = 19;
            this.label3.Text = "AntagningsDatum";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBoxAntagningsDatum
            // 
            this.textBoxAntagningsDatum.Location = new System.Drawing.Point(50, 552);
            this.textBoxAntagningsDatum.Multiline = true;
            this.textBoxAntagningsDatum.Name = "textBoxAntagningsDatum";
            this.textBoxAntagningsDatum.Size = new System.Drawing.Size(146, 41);
            this.textBoxAntagningsDatum.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 438);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 17;
            this.label2.Text = "StudentID";
            // 
            // textBoxStudentD
            // 
            this.textBoxStudentD.Location = new System.Drawing.Point(50, 462);
            this.textBoxStudentD.Multiline = true;
            this.textBoxStudentD.Name = "textBoxStudentD";
            this.textBoxStudentD.Size = new System.Drawing.Size(146, 41);
            this.textBoxStudentD.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 260);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Student Namn";
            // 
            // textBoxStudentNamn
            // 
            this.textBoxStudentNamn.Location = new System.Drawing.Point(50, 283);
            this.textBoxStudentNamn.Multiline = true;
            this.textBoxStudentNamn.Name = "textBoxStudentNamn";
            this.textBoxStudentNamn.Size = new System.Drawing.Size(146, 41);
            this.textBoxStudentNamn.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 351);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 20);
            this.label4.TabIndex = 28;
            this.label4.Text = "Personnummer";
            // 
            // textBoxPNR
            // 
            this.textBoxPNR.Location = new System.Drawing.Point(50, 374);
            this.textBoxPNR.Multiline = true;
            this.textBoxPNR.Name = "textBoxPNR";
            this.textBoxPNR.Size = new System.Drawing.Size(146, 41);
            this.textBoxPNR.TabIndex = 27;
            // 
            // textBoxKursIDS
            // 
            this.textBoxKursIDS.Location = new System.Drawing.Point(225, 288);
            this.textBoxKursIDS.Multiline = true;
            this.textBoxKursIDS.Name = "textBoxKursIDS";
            this.textBoxKursIDS.Size = new System.Drawing.Size(146, 41);
            this.textBoxKursIDS.TabIndex = 29;
            this.textBoxKursIDS.TextChanged += new System.EventHandler(this.textBoxKursIDS_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(220, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "KursID";
            // 
            // dataGridViewStudent
            // 
            this.dataGridViewStudent.Location = new System.Drawing.Point(13, 4);
            this.dataGridViewStudent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewStudent.Name = "dataGridViewStudent";
            this.dataGridViewStudent.Size = new System.Drawing.Size(1089, 231);
            this.dataGridViewStudent.TabIndex = 0;
            // 
            // RegStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 612);
            this.Controls.Add(this.dataGridViewStudent);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxKursIDS);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxPNR);
            this.Controls.Add(this.buttonTillbaka);
            this.Controls.Add(this.buttonLista);
            this.Controls.Add(this.buttonRegistrera);
            this.Controls.Add(this.listaStudenter);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxAntagningsDatum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxStudentD);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxStudentNamn);
            this.Name = "RegStudent";
            this.Text = "RegStudent";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonTillbaka;
        private System.Windows.Forms.Button buttonLista;
        private System.Windows.Forms.Button buttonRegistrera;
        private System.Windows.Forms.ListBox listaStudenter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxStudentNamn;
        private System.Windows.Forms.TextBox textBoxPNR;
        private System.Windows.Forms.TextBox textBoxStudentD;
        private System.Windows.Forms.TextBox textBoxAntagningsDatum;
        private System.Windows.Forms.TextBox textBoxKursIDS;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridViewStudent;
    }
}