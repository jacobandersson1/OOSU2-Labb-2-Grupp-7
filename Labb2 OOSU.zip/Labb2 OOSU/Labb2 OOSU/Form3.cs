﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public partial class RegKurs : Form
    {
        public RegKurs()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void RegKurs_Load(object sender, EventArgs e)
        {

        }

        private void textBoxKursNamn_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonRegistrera_Click(object sender, EventArgs e)
        {
            //input textbox till variabel 
            
            string kn = textBoxKursNamn.Text;
            string kursI = textBoxKursID.Text;
            string startd=textBoxStartDatum.Text;
            string slutd=textBoxSlutDatum.Text;

            //Skapar en instans av en ny kurs (Ny kurs). 
            classKurs ck = new classKurs(kn,kursI, startd,slutd);

            //Lägger till i LISTAN!!!!
            Program._KursLista.Add(ck);

            

            //tar bort input från textbox. 
            this.textBoxKursID.Clear();
            this.textBoxKursNamn.Clear();
            this.textBoxStartDatum.Clear();
            this.textBoxSlutDatum.Clear();
        }

        private void buttonLista_Click(object sender, EventArgs e)
        {
            dataGridViewKurs.DataSource = null;
            dataGridViewKurs.DataSource = Program._KursLista;
        }
      
        private void buttonTillbaka_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonRegLab_Click(object sender, EventArgs e)
        {

            ListBox.SelectedObjectCollection selected = new ListBox.SelectedObjectCollection(listaKurser);
            selected = listaKurser.SelectedItems;
            int index = selected.Count - 1;

            RegistreraLabb regLab = new RegistreraLabb();
            regLab.Show();
        }
    }
}
