﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public partial class RegistreraBetyg : Form

    {

        
        public RegistreraBetyg()
        {
            InitializeComponent();
            dataGridViewStudent.DataSource = null;
            dataGridViewStudent.DataSource = Program._StudentLista;
            adddata();


        }

        public void adddata()
        {
            ArrayList row = new ArrayList();
            DataGridViewComboBoxColumn comboBoxBetyg = new DataGridViewComboBoxColumn();
            comboBoxBetyg.HeaderText = "Betyg";
            comboBoxBetyg.Name = "Betyg";
            row = new ArrayList();
            row.AddRange(new String[] { "Godkänd", "Icke Godkänd" });
            comboBoxBetyg.Items.AddRange(row.ToArray());

            dataGridViewStudent.Columns.Add(comboBoxBetyg);





        }

  

        private void buttonSparaBetyg_Click(object sender, EventArgs e)
        {

         

        }
        private void buttonTillbaka_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

       

        
    }
}
