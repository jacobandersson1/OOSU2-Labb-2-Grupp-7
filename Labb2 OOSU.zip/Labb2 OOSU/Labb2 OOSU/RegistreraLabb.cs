﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public partial class RegistreraLabb : Form
    {
        public RegistreraLabb()
        {
            InitializeComponent();
        }

        private void buttonLista_Click(object sender, EventArgs e)
        {
            dataGridViewLab.DataSource = null;
            dataGridViewLab.DataSource = Program._LabbLista;
            

          
        }

        private void buttonRegistrera_Click(object sender, EventArgs e)
        {
            string lNamn = textBoxLabNamn.Text;
            string lId = textBoxLabID.Text;
            string lStDatum = textBoxStartDatum.Text;
            string lSlDatum = textBoxslutDatum.Text;

            classLabb cl = new classLabb(lNamn, lId, lStDatum, lSlDatum);

            Program._LabbLista.Add(cl);

            this.textBoxLabNamn.Clear();
            this.textBoxLabID.Clear();
            this.textBoxLabNamn.Clear();
            this.textBoxStartDatum.Clear();
            this.textBoxslutDatum.Clear();
        }

        private void buttonTabort_Click(object sender, EventArgs e)
        {
            ListBox.SelectedObjectCollection selected = new ListBox.SelectedObjectCollection(listaLab);
            selected = listaLab.SelectedItems;

            int index = selected.Count - 1;

            if(listaLab.SelectedIndex!=-1)
            {
                for(int i= selected.Count-1; i>=0; i--)
                {
                    listaLab.Items.Remove(selected[i]);
                }
                Program._LabbLista.RemoveAt(index);
            }

          

        }

        private void buttonTillbaka_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonRegBetyg_Click(object sender, EventArgs e)
        {
            ListBox.SelectedObjectCollection selected = new ListBox.SelectedObjectCollection(listaLab);
            selected = listaLab.SelectedItems;
            int index = selected.Count - 1;

            RegistreraBetyg regBetyg = new RegistreraBetyg();
            regBetyg.Show();
        }

        
    }
}
