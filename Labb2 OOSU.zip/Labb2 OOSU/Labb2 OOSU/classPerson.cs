﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{
    /// <summary>
    /// 
    /// </summary>
    public abstract class classPerson : IPerson
    {
        // Privata variabler
        private string _namn;
       private string _personNr; 
        //klassens egna

            public string Namn
        {
            get { return _namn; }
            set { _namn = value; }
        } 

        public string PersonNR
        {
            get { return _personNr; }
            set { _personNr = value; }
        }

       public classPerson (string personNr, string namn)
        {
            Namn = namn;
            PersonNR = personNr;
        }
    } 
}
