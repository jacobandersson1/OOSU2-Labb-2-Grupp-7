﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public class classKurs : IKurs
    {
        // pRIVATA VARIABLER

        private string _kursId;
        private string _kursNamn;
        private string _startDatum;
        private string _slutDatum;

        //skapar list som för UPPGIFTER till varje enskild kurs. 
       // List<classLabb> cl = new List<classLabb>();

        // Getters & setters
        public string KursID
        {
            get { return _kursId; }
            set { _kursId = value; }
        }

        public string KursNamn
        {
            get { return _kursNamn; }
            set { _kursNamn = value; }
        }

        public string StartDatum
        {
            get { return _startDatum; }
            set { _startDatum = value; }
        }

        public string SlutDatum
        {
            get { return _slutDatum; }
            set { _slutDatum = value; }
        }
       
        
        // konnstruktor
        public classKurs(string kursNamn, string kursId, string startDatum, string slutDatum)
        {
            KursID = kursId;
            KursNamn = kursNamn;
            StartDatum = startDatum;
            SlutDatum = slutDatum;
        }


        /*public void ListaKurser()
        {
            throw new NotImplementedException();
        }

        public void ListaStudenter()
        {
            throw new NotImplementedException();
        }

    */







    }
}
