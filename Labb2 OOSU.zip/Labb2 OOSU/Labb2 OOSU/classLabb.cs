﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{
    public class classLabb : ILabb
    {
        private string _namn;
        private string _labbID;
        private string _startDatum;
        private string _slutDatum;

        public string Namn
        {
            get { return _namn; }
            set { _namn = value; }
        }

        public string LabbId
        {
            get { return _labbID; }
            set { _labbID = value; }
        }


        public string StartDatum
        {
            get { return _startDatum; }
            set { _startDatum = value; }
        }

        public string SlutDatum
        {
            get { return _slutDatum; }
            set { _slutDatum = value; }
        }

        public classLabb(string namn, string labbid, string startdatum, string slutdatum)
        {
            Namn = namn;
            LabbId = labbid;
            StartDatum = startdatum;
            SlutDatum = slutdatum;


        }

       
    }
}
