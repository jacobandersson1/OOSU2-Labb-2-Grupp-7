﻿namespace Labb2_OOSU
{
    partial class RegistreraBetyg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonTillbaka = new System.Windows.Forms.Button();
            this.dataGridViewStudent = new System.Windows.Forms.DataGridView();
            this.buttonSparaBetyg = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonTillbaka
            // 
            this.buttonTillbaka.Location = new System.Drawing.Point(808, 528);
            this.buttonTillbaka.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonTillbaka.Name = "buttonTillbaka";
            this.buttonTillbaka.Size = new System.Drawing.Size(112, 35);
            this.buttonTillbaka.TabIndex = 8;
            this.buttonTillbaka.Text = "Tillbaka";
            this.buttonTillbaka.UseVisualStyleBackColor = true;
            this.buttonTillbaka.Click += new System.EventHandler(this.buttonTillbaka_Click);
            // 
            // dataGridViewStudent
            // 
            this.dataGridViewStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStudent.Location = new System.Drawing.Point(13, 28);
            this.dataGridViewStudent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewStudent.Name = "dataGridViewStudent";
            this.dataGridViewStudent.Size = new System.Drawing.Size(991, 395);
            this.dataGridViewStudent.TabIndex = 9;
            // 
            // buttonSparaBetyg
            // 
            this.buttonSparaBetyg.Location = new System.Drawing.Point(13, 433);
            this.buttonSparaBetyg.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonSparaBetyg.Name = "buttonSparaBetyg";
            this.buttonSparaBetyg.Size = new System.Drawing.Size(150, 35);
            this.buttonSparaBetyg.TabIndex = 11;
            this.buttonSparaBetyg.Text = "Spara betyg";
            this.buttonSparaBetyg.Click += new System.EventHandler(this.buttonSparaBetyg_Click);
            // 
            // RegistreraBetyg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 622);
            this.Controls.Add(this.buttonSparaBetyg);
            this.Controls.Add(this.dataGridViewStudent);
            this.Controls.Add(this.buttonTillbaka);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "RegistreraBetyg";
            this.Text = "RegistreraBetyg";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStudent)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonTillbaka;
        private System.Windows.Forms.DataGridView dataGridViewStudent;
        private System.Windows.Forms.Button buttonSparaBetyg;
    }
}