﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    static class Program
    {
        
         public static  List<classStudent> _StudentLista = new List<classStudent>(1);

         public static List<classKurs> _KursLista = new List<classKurs>(1);

         public static List<classLabb> _LabbLista = new List<classLabb>(1);

         public static List<classLarare> _LararLista = new List<classLarare>(1);
        
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
