﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public partial class RegStudent : Form
    {
        public RegStudent()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttonLista_Click(object sender, EventArgs e)
        {
            dataGridViewStudent.DataSource = null;
            dataGridViewStudent.DataSource = Program._StudentLista;
            listaStudenter.Items.Clear();

            foreach (classStudent S in Program._StudentLista)
            {
                listaStudenter.Items.Add(S.Namn);
            }
        }

        private void buttonRegistrera_Click(object sender, EventArgs e)
        {
            string sNamn = textBoxStudentNamn.Text;
            string sPnr = textBoxPNR.Text;
            string sId = textBoxStudentD.Text;
            string sAntagningsD = textBoxAntagningsDatum.Text;
            string sKursID = textBoxKursIDS.Text;
           
            
                 
            classStudent cs = new classStudent(sNamn,sPnr, sId, sAntagningsD,sKursID);

            Program._StudentLista.Add(cs);

            listaStudenter.Items.Add(cs.Namn);

            this.textBoxStudentNamn.Clear();
            this.textBoxPNR.Clear();
            this.textBoxStudentD.Clear();
            this.textBoxAntagningsDatum.Clear();
            this.textBoxKursIDS.Clear();
            
        }

    

        private void buttonTillbaka_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBoxKursIDS_TextChanged(object sender, EventArgs e)
        {

        }
            
        
    }
}
