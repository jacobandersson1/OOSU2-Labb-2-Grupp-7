﻿namespace Labb2_OOSU
{
    partial class AdministreraLärarlag
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1Registrera = new System.Windows.Forms.Button();
            this.button1Tillbaka = new System.Windows.Forms.Button();
            this.textBox1LärarID = new System.Windows.Forms.TextBox();
            this.textBox1LärarNamn = new System.Windows.Forms.TextBox();
            this.textBox1LärarLag = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1ListaLärare = new System.Windows.Forms.Button();
            this.dataGridViewLärarlag = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.textboxlärarPNR = new System.Windows.Forms.TextBox();
            this.PersonNr = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLärarlag)).BeginInit();
            this.SuspendLayout();
            // 
            // button1Registrera
            // 
            this.button1Registrera.Location = new System.Drawing.Point(545, 65);
            this.button1Registrera.Name = "button1Registrera";
            this.button1Registrera.Size = new System.Drawing.Size(75, 23);
            this.button1Registrera.TabIndex = 1;
            this.button1Registrera.Text = "Registrera";
            this.button1Registrera.UseVisualStyleBackColor = true;
            this.button1Registrera.Click += new System.EventHandler(this.button1Registrera_Click);
            // 
            // button1Tillbaka
            // 
            this.button1Tillbaka.Location = new System.Drawing.Point(570, 333);
            this.button1Tillbaka.Name = "button1Tillbaka";
            this.button1Tillbaka.Size = new System.Drawing.Size(75, 23);
            this.button1Tillbaka.TabIndex = 2;
            this.button1Tillbaka.Text = "Tillbaka";
            this.button1Tillbaka.UseVisualStyleBackColor = true;
            this.button1Tillbaka.Click += new System.EventHandler(this.button1Tillbaka_Click);
            // 
            // textBox1LärarID
            // 
            this.textBox1LärarID.Location = new System.Drawing.Point(161, 60);
            this.textBox1LärarID.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1LärarID.Multiline = true;
            this.textBox1LärarID.Name = "textBox1LärarID";
            this.textBox1LärarID.Size = new System.Drawing.Size(99, 28);
            this.textBox1LärarID.TabIndex = 4;
            // 
            // textBox1LärarNamn
            // 
            this.textBox1LärarNamn.Location = new System.Drawing.Point(36, 60);
            this.textBox1LärarNamn.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1LärarNamn.Multiline = true;
            this.textBox1LärarNamn.Name = "textBox1LärarNamn";
            this.textBox1LärarNamn.Size = new System.Drawing.Size(99, 28);
            this.textBox1LärarNamn.TabIndex = 5;
            // 
            // textBox1LärarLag
            // 
            this.textBox1LärarLag.Location = new System.Drawing.Point(284, 60);
            this.textBox1LärarLag.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1LärarLag.Multiline = true;
            this.textBox1LärarLag.Name = "textBox1LärarLag";
            this.textBox1LärarLag.Size = new System.Drawing.Size(99, 28);
            this.textBox1LärarLag.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Namn";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(158, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Lärarlag";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(0, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 12;
            // 
            // button1ListaLärare
            // 
            this.button1ListaLärare.Location = new System.Drawing.Point(36, 134);
            this.button1ListaLärare.Name = "button1ListaLärare";
            this.button1ListaLärare.Size = new System.Drawing.Size(75, 23);
            this.button1ListaLärare.TabIndex = 0;
            this.button1ListaLärare.Text = "Lista";
            this.button1ListaLärare.UseVisualStyleBackColor = true;
            this.button1ListaLärare.Click += new System.EventHandler(this.button1ListaLärare_Click);
            // 
            // dataGridViewLärarlag
            // 
            this.dataGridViewLärarlag.AllowUserToAddRows = false;
            this.dataGridViewLärarlag.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLärarlag.Location = new System.Drawing.Point(36, 163);
            this.dataGridViewLärarlag.Name = "dataGridViewLärarlag";
            this.dataGridViewLärarlag.ReadOnly = true;
            this.dataGridViewLärarlag.Size = new System.Drawing.Size(609, 150);
            this.dataGridViewLärarlag.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(281, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "LärarID";
            // 
            // textboxlärarPNR
            // 
            this.textboxlärarPNR.Location = new System.Drawing.Point(408, 60);
            this.textboxlärarPNR.Margin = new System.Windows.Forms.Padding(2);
            this.textboxlärarPNR.Multiline = true;
            this.textboxlärarPNR.Name = "textboxlärarPNR";
            this.textboxlärarPNR.Size = new System.Drawing.Size(99, 28);
            this.textboxlärarPNR.TabIndex = 14;
            // 
            // PersonNr
            // 
            this.PersonNr.AutoSize = true;
            this.PersonNr.Location = new System.Drawing.Point(404, 45);
            this.PersonNr.Name = "PersonNr";
            this.PersonNr.Size = new System.Drawing.Size(75, 20);
            this.PersonNr.TabIndex = 15;
            this.PersonNr.Text = "PersonNr";
            // 
            // AdministreraLärarlag
            // 
            this.ClientSize = new System.Drawing.Size(691, 381);
            this.Controls.Add(this.PersonNr);
            this.Controls.Add(this.textboxlärarPNR);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewLärarlag);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox1LärarLag);
            this.Controls.Add(this.textBox1LärarNamn);
            this.Controls.Add(this.textBox1LärarID);
            this.Controls.Add(this.button1Tillbaka);
            this.Controls.Add(this.button1Registrera);
            this.Controls.Add(this.button1ListaLärare);
            this.Name = "AdministreraLärarlag";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLärarlag)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1Registrera;
        private System.Windows.Forms.Button button1Tillbaka;
        private System.Windows.Forms.TextBox textBox1LärarID;
        private System.Windows.Forms.TextBox textBox1LärarNamn;
        private System.Windows.Forms.TextBox textBox1LärarLag;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1ListaLärare;
        private System.Windows.Forms.DataGridView dataGridViewLärarlag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textboxlärarPNR;
        private System.Windows.Forms.Label PersonNr;
    }
}