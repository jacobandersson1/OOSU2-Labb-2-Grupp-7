﻿namespace Labb2_OOSU
{
    partial class RegistreraLabb
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxLabID = new System.Windows.Forms.TextBox();
            this.buttonTillbaka = new System.Windows.Forms.Button();
            this.buttonLista = new System.Windows.Forms.Button();
            this.buttonRegistrera = new System.Windows.Forms.Button();
            this.listaLab = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxslutDatum = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxStartDatum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxLabNamn = new System.Windows.Forms.TextBox();
            this.buttonRegBetyg = new System.Windows.Forms.Button();
            this.dataGridViewLab = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLab)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 20);
            this.label4.TabIndex = 41;
            this.label4.Text = "LabID";
            // 
            // textBoxLabID
            // 
            this.textBoxLabID.Location = new System.Drawing.Point(50, 162);
            this.textBoxLabID.Multiline = true;
            this.textBoxLabID.Name = "textBoxLabID";
            this.textBoxLabID.Size = new System.Drawing.Size(146, 41);
            this.textBoxLabID.TabIndex = 40;
            // 
            // buttonTillbaka
            // 
            this.buttonTillbaka.Location = new System.Drawing.Point(628, 382);
            this.buttonTillbaka.Name = "buttonTillbaka";
            this.buttonTillbaka.Size = new System.Drawing.Size(108, 35);
            this.buttonTillbaka.TabIndex = 39;
            this.buttonTillbaka.Text = "Tillbaka";
            this.buttonTillbaka.UseVisualStyleBackColor = true;
            this.buttonTillbaka.Click += new System.EventHandler(this.buttonTillbaka_Click);
            // 
            // buttonLista
            // 
            this.buttonLista.Location = new System.Drawing.Point(316, 272);
            this.buttonLista.Name = "buttonLista";
            this.buttonLista.Size = new System.Drawing.Size(134, 35);
            this.buttonLista.TabIndex = 37;
            this.buttonLista.Text = "Lista Lab";
            this.buttonLista.UseVisualStyleBackColor = true;
            this.buttonLista.Click += new System.EventHandler(this.buttonLista_Click);
            // 
            // buttonRegistrera
            // 
            this.buttonRegistrera.Location = new System.Drawing.Point(316, 325);
            this.buttonRegistrera.Name = "buttonRegistrera";
            this.buttonRegistrera.Size = new System.Drawing.Size(134, 35);
            this.buttonRegistrera.TabIndex = 36;
            this.buttonRegistrera.Text = "Registrera Lab";
            this.buttonRegistrera.UseVisualStyleBackColor = true;
            this.buttonRegistrera.Click += new System.EventHandler(this.buttonRegistrera_Click);
            // 
            // listaLab
            // 
            this.listaLab.FormattingEnabled = true;
            this.listaLab.ItemHeight = 20;
            this.listaLab.Location = new System.Drawing.Point(316, 9);
            this.listaLab.Name = "listaLab";
            this.listaLab.Size = new System.Drawing.Size(295, 244);
            this.listaLab.TabIndex = 35;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 332);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 34;
            this.label3.Text = "SlutDatum";
            // 
            // textBoxslutDatum
            // 
            this.textBoxslutDatum.Location = new System.Drawing.Point(50, 368);
            this.textBoxslutDatum.Multiline = true;
            this.textBoxslutDatum.Name = "textBoxslutDatum";
            this.textBoxslutDatum.Size = new System.Drawing.Size(146, 41);
            this.textBoxslutDatum.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 231);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 32;
            this.label2.Text = "StartDatum";
            // 
            // textBoxStartDatum
            // 
            this.textBoxStartDatum.Location = new System.Drawing.Point(50, 266);
            this.textBoxStartDatum.Multiline = true;
            this.textBoxStartDatum.Name = "textBoxStartDatum";
            this.textBoxStartDatum.Size = new System.Drawing.Size(146, 41);
            this.textBoxStartDatum.TabIndex = 31;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 20);
            this.label1.TabIndex = 30;
            this.label1.Text = "Lab Namn";
            // 
            // textBoxLabNamn
            // 
            this.textBoxLabNamn.Location = new System.Drawing.Point(50, 69);
            this.textBoxLabNamn.Multiline = true;
            this.textBoxLabNamn.Name = "textBoxLabNamn";
            this.textBoxLabNamn.Size = new System.Drawing.Size(146, 41);
            this.textBoxLabNamn.TabIndex = 29;
            // 
            // buttonRegBetyg
            // 
            this.buttonRegBetyg.Location = new System.Drawing.Point(482, 272);
            this.buttonRegBetyg.Name = "buttonRegBetyg";
            this.buttonRegBetyg.Size = new System.Drawing.Size(132, 37);
            this.buttonRegBetyg.TabIndex = 42;
            this.buttonRegBetyg.Text = "Reg Betyg";
            this.buttonRegBetyg.UseVisualStyleBackColor = true;
            this.buttonRegBetyg.Click += new System.EventHandler(this.buttonRegBetyg_Click);
            // 
            // dataGridViewLab
            // 
            this.dataGridViewLab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLab.Location = new System.Drawing.Point(316, 9);
            this.dataGridViewLab.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridViewLab.Name = "dataGridViewLab";
            this.dataGridViewLab.Size = new System.Drawing.Size(360, 246);
            this.dataGridViewLab.TabIndex = 43;
            // 
            // RegistreraLabb
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 449);
            this.Controls.Add(this.dataGridViewLab);
            this.Controls.Add(this.buttonRegBetyg);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxLabID);
            this.Controls.Add(this.buttonTillbaka);
            this.Controls.Add(this.buttonLista);
            this.Controls.Add(this.buttonRegistrera);
            this.Controls.Add(this.listaLab);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxslutDatum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxStartDatum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxLabNamn);
            this.Name = "RegistreraLabb";
            this.Text = "RegistreraLabb";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLab)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxLabID;
        private System.Windows.Forms.Button buttonTillbaka;
        private System.Windows.Forms.Button buttonLista;
        private System.Windows.Forms.Button buttonRegistrera;
        private System.Windows.Forms.ListBox listaLab;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxslutDatum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxStartDatum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxLabNamn;
        private System.Windows.Forms.Button buttonRegBetyg;
        private System.Windows.Forms.DataGridView dataGridViewLab;
    }
}