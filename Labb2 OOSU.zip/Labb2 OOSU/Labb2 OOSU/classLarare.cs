﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labb2_OOSU
{
    public class classLarare : classPerson
    {
        
        //Klassens egna
       
        private string _lararID;
        private string _lararLag;

         //_LARARID _ ANSTALLNIUNGSDATUKM _UNDERVISNINGSAMNE

        //LärarNamn, LärarID, Lärarlag
        

      

        public string LararId
        {
            get { return _lararID; }
            set { _lararID = value; }
        }

        public string LararLag
        {
            get { return _lararLag; }
            set { _lararLag = value; }
        }
        public classLarare(string namn, string lararLag,  string lararID , string personNr) : base(namn ,personNr)
        {
            Namn = namn;
            LararLag = lararLag;
            LararId = lararID;
            PersonNR = personNr;
          
           

        }
            
        /* public string ListaLarare()
         {

         }*/
    }
   
   
}
