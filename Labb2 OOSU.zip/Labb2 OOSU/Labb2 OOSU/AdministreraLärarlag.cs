﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public partial class AdministreraLärarlag : Form
    {
        public AdministreraLärarlag()
        {
            InitializeComponent();
        }
        private void button1Registrera_Click(object sender, EventArgs e)
        {
            string LärarNamn = textBox1LärarNamn.Text;
            string Lärarlag = textBox1LärarLag.Text;
            string  LärarId = textBox1LärarID.Text;
            string personNr = textboxlärarPNR.Text;
        
            classLarare cl = new classLarare(LärarNamn, LärarId, Lärarlag, personNr);

            
            Program._LararLista.Add(cl);

            


            this.textBox1LärarNamn.Clear();
            this.textBox1LärarLag.Clear();
            this.textBox1LärarID.Clear();
            this.textboxlärarPNR.Clear();
        }

        private void button1ListaLärare_Click(object sender, EventArgs e)
        {
            dataGridViewLärarlag.DataSource = null;
            dataGridViewLärarlag.DataSource = Program._LararLista;
            
            
         
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void button1Tillbaka_Click(object sender, EventArgs e)
        {
            this.Close();
        }


       
    }
}
