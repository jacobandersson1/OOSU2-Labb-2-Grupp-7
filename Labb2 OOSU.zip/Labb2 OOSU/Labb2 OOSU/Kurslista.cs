﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Labb2_OOSU
{
    public partial class Kurslista : Form
    {
      
        public Kurslista()
        {
            InitializeComponent();
        }

        
    }
}
